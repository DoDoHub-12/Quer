@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul
cd /d "%~dp0app"
title Unified Solver

set "PY="
set "PYARG="

rem --- 1) python from PATH ---
where python >nul 2>&1
if not errorlevel 1 (
    python -c "import sys" >nul 2>&1
    if not errorlevel 1 set "PY=python"
)

rem --- 2) the "py" launcher ---
if not defined PY (
    where py >nul 2>&1
    if not errorlevel 1 (
        py -3 -c "import sys" >nul 2>&1
        if not errorlevel 1 (
            set "PY=py"
            set "PYARG=-3"
        )
    )
)

rem --- 3) standard Python install folders ---
if not defined PY (
    for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python*") do (
        if exist "%%~fD\python.exe" set "PY=%%~fD\python.exe"
    )
)
if not defined PY (
    for /d %%D in ("%ProgramFiles%\Python*") do (
        if exist "%%~fD\python.exe" set "PY=%%~fD\python.exe"
    )
)
set "PF86=%ProgramFiles(x86)%"
if not defined PY (
    for /d %%D in ("!PF86!\Python*") do (
        if exist "%%~fD\python.exe" set "PY=%%~fD\python.exe"
    )
)

if not defined PY (
    echo.
    echo ========================================================
    echo [!] Python was not found on this computer.
    echo     Please install Python 3 from: https://www.python.org/downloads/
    echo     IMPORTANT: Check "Add python.exe to PATH" during setup.
    echo ========================================================
    echo.
    pause
    exit /b 1
)

echo [*] Using: !PY! !PYARG!
echo [*] Starting server ...
echo [*] The tool dashboard will open in your browser automatically!
echo.
start "Unified Solver" cmd /k "!PY!" !PYARG! server.py
exit /b 0
