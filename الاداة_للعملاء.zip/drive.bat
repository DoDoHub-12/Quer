@echo off
setlocal enabledelayedexpansion
chcp 65001 >nul
cd /d "%~dp0app"
title Unified Solver - Setup

echo ========================================================
echo       Unified Solver - Dependencies Setup
echo ========================================================
echo.

set "PY="
set "PYARG="

rem --- 1) python from PATH ---
where python >nul 2>&1
if not errorlevel 1 (
    python -c "import sys" >nul 2>&1
    if not errorlevel 1 set "PY=python"
)

rem --- 2) the "py" launcher ---
if not defined PY (
    where py >nul 2>&1
    if not errorlevel 1 (
        py -3 -c "import sys" >nul 2>&1
        if not errorlevel 1 (
            set "PY=py"
            set "PYARG=-3"
        )
    )
)

rem --- 3) standard Python install folders ---
if not defined PY (
    for /d %%D in ("%LOCALAPPDATA%\Programs\Python\Python*") do (
        if exist "%%~fD\python.exe" set "PY=%%~fD\python.exe"
    )
)
if not defined PY (
    for /d %%D in ("%ProgramFiles%\Python*") do (
        if exist "%%~fD\python.exe" set "PY=%%~fD\python.exe"
    )
)
set "PF86=%ProgramFiles(x86)%"
if not defined PY (
    for /d %%D in ("!PF86!\Python*") do (
        if exist "%%~fD\python.exe" set "PY=%%~fD\python.exe"
    )
)

if not defined PY (
    echo.
    echo ========================================================
    echo [!] Python was not found on this computer.
    echo     Please install Python 3 from: https://www.python.org/downloads/
    echo     IMPORTANT: Check "Add python.exe to PATH" during setup.
    echo ========================================================
    echo.
    pause
    exit /b 1
)

echo [*] Using: !PY! !PYARG!
echo.

echo [1/3] Upgrading pip, setuptools, wheel ...
"!PY!" !PYARG! -m pip install --upgrade pip setuptools wheel
echo.

echo [2/3] Installing dependencies (greenlet, playwright) ...
"!PY!" !PYARG! -m pip install --upgrade --force-reinstall "greenlet>=3.0.0"
"!PY!" !PYARG! -m pip install -r requirements.txt
if errorlevel 1 (
    echo.
    echo [!] Failed to install dependencies. Check your internet connection and try again.
    echo.
    pause
    exit /b 1
)
echo.

echo [3/3] Checking Chromium browser engine ...
set "HAVE_BROWSER="
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "HAVE_BROWSER=1"
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "HAVE_BROWSER=1"
if exist "%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe" set "HAVE_BROWSER=1"
if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "HAVE_BROWSER=1"
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set "HAVE_BROWSER=1"
if not defined HAVE_BROWSER (
    echo [*] Installing Chromium browser engine ...
    "!PY!" !PYARG! -m playwright install chromium
) else (
    echo [*] Chrome/Edge found.
)

echo.
echo [*] Verifying installation ...
"!PY!" !PYARG! -c "import greenlet, playwright; from playwright.sync_api import sync_playwright; print('Dependencies OK')"
if errorlevel 1 (
    echo.
    echo [!] Reinstalling greenlet binary wheel ...
    "!PY!" !PYARG! -m pip install --only-binary :all: --force-reinstall greenlet playwright
)

echo.
echo ========================================================
echo    Setup completed successfully!  (^_^)
echo    You can now run [ run.bat ] at any time.
echo ========================================================
echo.
pause
exit /b 0
